FRONTLINE SIMULATOR v5 (prototype)

HOW TO PLAY
1. Open index.html in Chrome, or upload it to a static website host.
2. Choose attacker and defender countries.
3. Choose RED or BLUE placement, select a force type, then tap the map to place units.
4. Press START WAR. Units move toward the nearest enemy and attack when close.
5. PAUSE/RESUME and RESET are available.

UNIT RULES
- Infantry: 100 HP, 1 damage per attack.
- Tank: 500 HP, 5 damage per attack.
- Missile: one-use attack, 10 damage, no health bar.
- FPV: one-use attack, 10 damage, no health bar.

NOTES / LIMITATIONS
- This is a playable prototype, not a complete territorial warfare simulator.
- Country selection uses public GeoJSON borders and Esri satellite tiles; internet is required.
- Contested land is represented by light dashed circular zones around moving infantry/tanks, not exact captured country polygons.
- The white dashed front line and full sector-based territory capture system are not implemented yet.
- No random bullet/tracer lines are drawn.
