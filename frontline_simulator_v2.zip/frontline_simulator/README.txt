FRONTLINE SIMULATOR v2

Open index.html in a browser with an internet connection.

Features:
- 2D world map with country borders and selectable countries
- Red attacker and blue defender
- Military force selector
- Automatically generated white dashed frontline
- Start, pause, resume and reset
- Moving frontline and basic simulated progress
- Simple bullet, missile and impact flash effects

Important limitations:
- This is an early playable prototype, not a finished strategy game.
- It uses OpenStreetMap tiles and a public GeoJSON country-boundary file, so internet is required.
- The current simulation changes the frontline and country fills in a simplified way. It does not model real combat, detailed local territory polygons, independent battles in multiple sectors, or actual moving unit formations.
- Unit markers remain stationary by design.
- Effects are visual placeholders and are not a physically accurate simulation.
